export const API_KEY = '5b0750d0425843e9a104d028a6bcc178';
export const API_BASE_URL = 'http://api.openweathermap.org/';